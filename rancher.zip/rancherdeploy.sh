#!/bin/bash

# Set the default subscription.
# az account set -s XXXXXXXXXXXXXXXXXXXXXX

echo 'account set'

# Set Location and Resource Group
# Optional Pull syntax

# RgName=`az group list --query '[0].name' --output tsv`
# Location=`az group list --query '[0].location' --output tsv`

RgName=clustertest5
Location=canadacentral

az group create -n $RgName -l $Location
echo '----------------------------------------------'
echo 'group '$RgName' created in '$Location''
echo '----------------------------------------------'
echo '----------------------------------------------'
date
# Create a Virtual Network for the VMs
# Default class A/C subnets will be applied
echo '------------------------------------------'
echo 'Creating a Virtual Network for the VMs'
az network vnet create \
    --resource-group $RgName \
    --location $Location \
    --name $RgName-PortalVnet \
    --subnet-name $RgName-PortalSubnet

# Create a Network Security Group
echo '------------------------------------------'
echo 'Creating a Network Security Group'
az network nsg create \
    --resource-group $RgName \
    --name $RgName-PortalNSG \
    --location $Location

# Create a Network Security Group PORT 80 Rule
az network nsg rule create -g $RgName --nsg-name $RgName-PortalNSG -n AllowAll80 --priority 101 \
                            --source-address-prefixes 'Internet' --source-port-ranges '*' \
                            --destination-address-prefixes '*' --destination-port-ranges 80 --access Allow \
                            --protocol Tcp --description "Allow all port 80 traffic"

# Create a Network Security Group PORT 443 Rule
az network nsg rule create -g $RgName --nsg-name $RgName-PortalNSG -n AllowAll443 --priority 102 \
                            --source-address-prefixes 'Internet' --source-port-ranges '*' \
                            --destination-address-prefixes '*' --destination-port-ranges 443 --access Allow \
                            --protocol Tcp --description "Allow all SSL port 443 traffic"

# Create a Network Security Group PORT 22 Rule
az network nsg rule create -g $RgName --nsg-name $RgName-PortalNSG -n AllowAll22 --priority 103 \
                            --source-address-prefixes 'Internet' --source-port-ranges '*' \
                            --destination-address-prefixes '*' --destination-port-ranges 22 --access Allow \
                            --protocol Tcp --description "Allow all SSH port 22 traffic"



# Create the NIC
for i in `seq 1 2`; do
  echo '------------------------------------------'
  echo 'Creating webNic'$i
  az network nic create \
    --resource-group $RgName \
    --name $RgName-webNic$i \
    --vnet-name $RgName-PortalVnet \
    --subnet $RgName-PortalSubnet \
    --network-security-group $RgName-PortalNSG \
    --location $Location
done

# Create an availability set
echo '------------------------------------------'
echo 'Creating an availability set'
az vm availability-set create \
    --resource-group $RgName \
    --name $RgName-portalAvailabilitySet

# Create 2 VM's from a template
for i in `seq 1 2`; do
    echo '------------------------------------------'
    echo 'Creating webVM'$i
    az vm create \
        --admin-username kevin \
        --resource-group $RgName \
        --name $RgName-webVM$i \
        --nics $RgName-webNic$i \
        --location $Location \
        --image ubuntults \
        --availability-set $RgName-portalAvailabilitySet \
        --ssh-key-values ~/.ssh/rke_rsa.pub
        --custom-data rancherinit.txt
done

# Done
# to execute cloud-init post install commands from local file, currently using removed last line in previous az vm create loop
# --custom-data cloud-init.txt, where the file exists in same folder as script.
# Multiple SSH PUB keys can be added space delimited filepath

echo '--------------------------------------------------------'
echo '             VM Setup Completed'
echo '--------------------------------------------------------'

echo '--------------------------------------------------------'
echo '             Starting Load Balancer Deploy'
echo '--------------------------------------------------------'


    az network public-ip create \
      --resource-group $RgName \
      --location $Location \
      --allocation-method Static \
      --name $RgName-PublicIP \
      --sku Standard

   az network lb create \
      --resource-group $RgName \
      --name $RgName-LoadBalancer \
      --public-ip-address $RgName-PublicIP \
      --frontend-ip-name $RgName-FrontEndPool \
      --backend-pool-name $RgName-BackEndPool \
      --sku Standard

  az network lb probe create \
     --resource-group $RgName \
     --lb-name $RgName-LoadBalancer \
     --name $RgName-HealthProbe \
     --protocol tcp \
     --port 22

  az network lb rule create \
      --resource-group $RgName \
      --lb-name $RgName-LoadBalancer \
      --name $RgName-HTTPRule \
      --protocol tcp \
      --frontend-port 80 \
      --backend-port 80 \
      --frontend-ip-name $RgName-FrontEndPool \
      --backend-pool-name $RgName-BackEndPool

  az network lb rule create \
      --resource-group $RgName \
      --lb-name $RgName-LoadBalancer \
      --name $RgName-HTTPSRule \
      --protocol tcp \
      --frontend-port 443 \
      --backend-port 443 \
      --frontend-ip-name $RgName-FrontEndPool \
      --backend-pool-name $RgName-BackEndPool

  az network lb rule create \
      --resource-group $RgName \
      --lb-name $RgName-LoadBalancer \
      --name $RgName-SSHRule \
      --protocol tcp \
      --frontend-port 22 \
      --backend-port 22 \
      --frontend-ip-name $RgName-FrontEndPool \
      --backend-pool-name $RgName-BackEndPool

  az network nic ip-config update \
      --resource-group $RgName \
      --nic-name $RgName-webNic1 \
      --name ipconfig1 \
      --lb-name $RgName-LoadBalancer \
      --lb-address-pools $RgName-BackEndPool

  az network nic ip-config update \
      --resource-group $RgName \
      --nic-name $RgName-webNic2 \
      --name ipconfig1 \
      --lb-name $RgName-LoadBalancer \
      --lb-address-pools $RgName-BackEndPool

  az network public-ip show \
      --resource-group $RgName \
      --name $RgName-PublicIP \
      --query [ipAddress] \
      --output tsv

echo '--------------------------------------------------------'
echo '  Load balancer deployed to the IP Address shown above'
echo '--------------------------------------------------------'

