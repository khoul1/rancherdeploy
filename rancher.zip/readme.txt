prerequisite AZ CLI

connect to Azure and then execute the bash script

open linux console

az login
  follow login steps

az account set -s <subscription_id>

bash ./script.sh




